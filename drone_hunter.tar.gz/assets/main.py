# ==========================================
# DRONE HUNTER - Unit 2 Project (Dimash Kozhakhmet)
# ==========================================
# UNIT 2 MATH & AI EXPLANATION
# ==========================================
# VECTORS: All positions, velocities, and directions are pygame.Vector2.
#
# DISTANCE: Collisions happen when the distance between centers is less
# than the two radii added together. Distance also limits the battery
# magnet (MAGNET_RANGE) and how far hunters can see (DETECTION_RANGE).
#
# NORMALIZATION: (player - battery).normalize() gives a length-1 arrow
# toward the player for the magnet pull. (player - hunter).normalize()
# gives the knockback direction when a hunter hits you.
#
# ANGLES / SIN / COS: forward_from_angle() turns an angle into a direction
# with (cos, -sin) (minus because pygame's y-axis points down). The player
# rotates with A/D. Hunters use atan2 to find the angle to their target
# and turn toward it a few degrees per frame.
#
# VELOCITY + ACCELERATION: Thrust adds acceleration in the facing
# direction: velocity += acceleration, velocity *= DRAG, position +=
# velocity, capped at MAX_SPEED. Turning doesn't change velocity, so the
# drone drifts (momentum). Magnet-pulled batteries use the same physics.
#
# DOT PRODUCT: A hunter compares its forward vector with the normalized
# direction to the player. For unit vectors, dot = cos(angle between), so
# dot > cos(35 degrees) means the player is inside the hunter's 70-degree
# vision cone. Hunters can't see behind them.
#
# AI (PERCEPTION -> DECISION -> ACTION):
# PERCEPTION: can_see() checks distance AND the dot product.
# DECISION: sees player -> CHASE; lost sight -> SEARCH; search timer
# ends -> PATROL; just hit player -> RECHARGE (blind for 2 seconds).
# ACTION: PATROL flies between random waypoints, CHASE turns toward the
# player faster, SEARCH flies to the last seen spot and spins to look.
# ==========================================
import asyncio
import math
import random
import sys
import pygame

# True when running in a web browser through pygbag (GitHub Pages)
IS_WEB = sys.platform == "emscripten"
QUIT_HINT = "" if IS_WEB else "   ESC: quit"

WIDTH, HEIGHT, FPS = 900, 650, 60

# Player
TURN_SPEED, THRUST, DRAG, MAX_SPEED, PLAYER_RADIUS = 4, 0.25, 0.98, 7, 16
MAX_POWER, IDLE_DRAIN, THRUST_DRAIN = 100, 0.04, 0.06

# Batteries
BATTERY_COUNT, BATTERY_RADIUS, BATTERY_POWER, WIN_SCORE = 4, 14, 25, 10
MAGNET_RANGE, MAGNET_PULL, MAGNET_MIN_STRENGTH, BATTERY_DRAG = 120, 0.4, 0.4, 0.92

# Hunters
HUNTER_COUNT, HUNTER_RADIUS = 3, 18
PATROL_SPEED, PATROL_TURN, CHASE_SPEED, CHASE_TURN = 2.0, 3, 3.3, 4
DETECTION_RANGE, CHASE_VIEW_RANGE, FOV_HALF_ANGLE = 220, 320, 35
FOV_THRESHOLD = math.cos(math.radians(FOV_HALF_ANGLE))  # about 0.82
HUNTER_DAMAGE, KNOCKBACK, HIT_COOLDOWN = 20, 7, 60
SEARCH_TIME, SEARCH_SPIN, RECHARGE_TIME, WAYPOINT_DIST = 180, 3, 120, 30

# Colors
BG, PLAYER_COLOR, FLAME_COLOR = (12, 14, 24), (80, 200, 255), (255, 170, 60)
GREEN, RED, TEXT, DARK = (90, 230, 120), (240, 70, 90), (230, 230, 240), (50, 50, 70)
STATE_COLORS = {"PATROL": (255, 220, 90), "CHASE": RED,
                "SEARCH": (255, 150, 60), "RECHARGE": (120, 120, 140)}


def forward_from_angle(angle):
    """Angle in degrees -> unit direction vector (y negated for pygame)."""
    radians = math.radians(angle)
    return pygame.Vector2(math.cos(radians), -math.sin(radians))


def angle_toward(start, target):
    """Direction -> angle in degrees (the reverse of forward_from_angle)."""
    d = target - start
    return math.degrees(math.atan2(-d.y, d.x))


def turn_toward(angle, target, max_turn):
    # Wrap the difference into -180..180 so we always turn the short way
    diff = (target - angle + 180) % 360 - 180
    return angle + max(-max_turn, min(max_turn, diff))


def random_point(avoid, min_dist):
    while True:
        p = pygame.Vector2(random.randint(40, WIDTH - 40), random.randint(60, HEIGHT - 40))
        if p.distance_to(avoid) >= min_dist:
            return p


def touching(a, b, radius_a, radius_b):
    # Distance-based collision: circles overlap if centers are closer than both radii
    return a.position.distance_to(b.position) < radius_a + radius_b


class Player:
    def __init__(self):
        self.position = pygame.Vector2(WIDTH / 2, HEIGHT / 2)
        self.velocity = pygame.Vector2(0, 0)
        self.angle, self.thrusting = 90, False
        self.power, self.hit_cooldown = MAX_POWER, 0

    def update(self, keys):
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            self.angle += TURN_SPEED
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            self.angle -= TURN_SPEED
        self.thrusting = keys[pygame.K_w] or keys[pygame.K_UP]

        # Thrust pushes the way we FACE, but velocity keeps old momentum
        if self.thrusting:
            self.velocity += forward_from_angle(self.angle) * THRUST
        self.velocity *= DRAG
        if self.velocity.length() > MAX_SPEED:
            self.velocity.scale_to_length(MAX_SPEED)
        self.position += self.velocity
        self.position.x %= WIDTH   # screen wrap
        self.position.y %= HEIGHT

        # Thrusting costs extra power, so coasting on momentum saves energy
        self.power = max(0, self.power - IDLE_DRAIN - (THRUST_DRAIN if self.thrusting else 0))
        self.hit_cooldown = max(0, self.hit_cooldown - 1)

    def take_hit(self, hunter):
        self.power = max(0, self.power - HUNTER_DAMAGE)
        self.hit_cooldown = HIT_COOLDOWN
        away = self.position - hunter.position   # points from hunter to player
        if away.length() > 0:                     # can't normalize a zero vector
            self.velocity = away.normalize() * KNOCKBACK

    def draw(self, screen):
        if self.hit_cooldown and (self.hit_cooldown // 5) % 2 == 0:
            return  # flicker while invulnerable
        f = forward_from_angle(self.angle)
        s = f.rotate(90)  # perpendicular, for the wing tips
        r, back = PLAYER_RADIUS, self.position - f * PLAYER_RADIUS * 0.7
        if self.thrusting:
            pygame.draw.polygon(screen, FLAME_COLOR,
                                [self.position - f * r * 1.5, back + s * r * 0.35, back - s * r * 0.35])
        pygame.draw.polygon(screen, PLAYER_COLOR,
                            [self.position + f * r, back + s * r * 0.7, back - s * r * 0.7], 2)


class Battery:
    def __init__(self, player):
        self.respawn(player)

    def respawn(self, player):
        self.position = random_point(player.position, 150)
        self.velocity = pygame.Vector2(0, 0)
        self.pulled = False

    def update(self, player):
        to_player = player.position - self.position
        distance = to_player.length()
        self.pulled = 0 < distance < MAGNET_RANGE
        if self.pulled:
            # Normalize = keep the direction, remove the distance
            direction = to_player.normalize()
            # Pull grows from MAGNET_MIN_STRENGTH at the edge to 1 up close
            strength = MAGNET_MIN_STRENGTH + (1 - MAGNET_MIN_STRENGTH) * (1 - distance / MAGNET_RANGE)
            self.velocity += direction * MAGNET_PULL * strength
        self.velocity *= BATTERY_DRAG
        self.position += self.velocity

    def draw(self, screen, player):
        if self.pulled:  # "tractor beam" shows the magnet working
            pygame.draw.line(screen, GREEN, self.position, player.position, 1)
        body = pygame.Rect(0, 0, BATTERY_RADIUS * 1.4, BATTERY_RADIUS * 2)
        body.center = self.position
        pygame.draw.rect(screen, GREEN, body, 2, border_radius=3)
        pygame.draw.rect(screen, GREEN, (body.centerx - 4, body.top - 4, 8, 4))


class Hunter:
    def __init__(self, player):
        self.position = random_point(player.position, 250)
        self.angle = random.uniform(0, 360)
        self.waypoint = random_point(self.position, 0)
        self.last_seen = pygame.Vector2(self.position)
        self.state, self.timer = "PATROL", 0

    def view_range(self):
        return CHASE_VIEW_RANGE if self.state == "CHASE" else DETECTION_RANGE

    def can_see(self, player):
        """PERCEPTION: close enough (distance) AND inside the cone (dot product)."""
        to_player = player.position - self.position
        if not 0 < to_player.length() <= self.view_range():
            return False
        # Unit vectors: dot = cos(angle). 1 = straight ahead, 0 = side, -1 = behind
        dot = forward_from_angle(self.angle).dot(to_player.normalize())
        return dot > FOV_THRESHOLD

    def update(self, player):
        # DECISION
        if self.state == "RECHARGE":
            self.timer -= 1
            if self.timer <= 0:
                self.state = "PATROL"
        elif self.can_see(player):
            self.state = "CHASE"
            self.last_seen = pygame.Vector2(player.position)
        elif self.state == "CHASE":
            self.state, self.timer = "SEARCH", SEARCH_TIME
        elif self.state == "SEARCH":
            self.timer -= 1
            if self.timer <= 0:
                self.state = "PATROL"

        # ACTION
        if self.state == "CHASE":
            self.move_toward(player.position, CHASE_SPEED, CHASE_TURN)
        elif self.state == "SEARCH":
            if self.position.distance_to(self.last_seen) > WAYPOINT_DIST:
                self.move_toward(self.last_seen, PATROL_SPEED, PATROL_TURN)
            else:
                self.angle += SEARCH_SPIN  # spin so the cone sweeps the area
        else:  # PATROL or RECHARGE
            if self.position.distance_to(self.waypoint) < WAYPOINT_DIST:
                self.waypoint = random_point(self.position, 0)
            self.move_toward(self.waypoint, PATROL_SPEED, PATROL_TURN)

    def move_toward(self, target, speed, turn_speed):
        # Turn gradually toward the target, then move the way we're facing
        self.angle = turn_toward(self.angle, angle_toward(self.position, target), turn_speed)
        self.position += forward_from_angle(self.angle) * speed

    def hit_player(self):
        self.state, self.timer = "RECHARGE", RECHARGE_TIME

    def draw_cone(self, cone_layer):
        if self.state != "RECHARGE":
            points = [self.position] + [
                self.position + forward_from_angle(self.angle + a) * self.view_range()
                for a in range(-FOV_HALF_ANGLE, FOV_HALF_ANGLE + 1, 5)]
            pygame.draw.polygon(cone_layer, STATE_COLORS[self.state] + (45,), points)

    def draw(self, screen, small_font):
        f = forward_from_angle(self.angle)
        s, r, p = f.rotate(90), HUNTER_RADIUS, self.position
        pygame.draw.polygon(screen, RED, [p + f * r, p + s * r * 0.7, p - f * r * 0.6, p - s * r * 0.7], 2)
        pygame.draw.circle(screen, RED, p + f * r * 0.4, 3)  # "eye"
        label = small_font.render(self.state, True, STATE_COLORS[self.state])
        screen.blit(label, label.get_rect(center=(p.x, p.y - r - 12)))


def draw_hud(screen, font, player, score):
    screen.blit(font.render(f"Batteries: {score}/{WIN_SCORE}", True, TEXT), (15, 12))
    bar = pygame.Rect(WIDTH - 215, 15, 200, 18)
    pygame.draw.rect(screen, DARK, bar, border_radius=4)
    fill = bar.copy()
    fill.width = int(bar.width * player.power / MAX_POWER)
    pygame.draw.rect(screen, RED if player.power < 30 else GREEN, fill, border_radius=4)
    label = font.render("POWER", True, TEXT)
    screen.blit(label, (bar.x - label.get_width() - 10, 12))


def centered(font, text, color, y):
    surface = font.render(text, True, color)
    return surface, surface.get_rect(center=(WIDTH / 2, y))


def draw_menu(screen, big_font, font, title, color, lines):
    shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    shade.fill((0, 0, 0, 170))
    screen.blit(shade, (0, 0))
    screen.blit(*centered(big_font, title, color, HEIGHT / 2 - 150))
    for i, line in enumerate(lines):
        screen.blit(*centered(font, line, TEXT, HEIGHT / 2 - 80 + i * 32))


START_LINES = ["Your power is draining! Collect 10 batteries to win.", "",
               "W / UP: thrust (uses extra power)", "A, D / LEFT, RIGHT: rotate", "",
               "Hunter drones patrol with vision cones.",
               "Get spotted and they CHASE you. A hit costs 20 power.",
               "Tip: they can't see behind them.", "", "Press SPACE to start"]


def new_game():
    player = Player()
    return (player, [Battery(player) for _ in range(BATTERY_COUNT)],
            [Hunter(player) for _ in range(HUNTER_COUNT)], 0, 0)


async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Drone Hunter")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("consolas", 22)
    big_font = pygame.font.SysFont("consolas", 48, bold=True)
    small_font = pygame.font.SysFont("consolas", 13, bold=True)
    cone_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)  # see-through cones

    player, batteries, hunters, score, frames = new_game()
    state = "START"

    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            quit_pressed = event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE
            # A browser tab can't be "quit", so ESC only quits on the desktop
            if event.type == pygame.QUIT or (quit_pressed and not IS_WEB):
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if state == "START" and event.key == pygame.K_SPACE:
                    state = "PLAYING"
                elif state in ("WON", "LOST") and event.key == pygame.K_r:
                    player, batteries, hunters, score, frames = new_game()
                    state = "PLAYING"

        if state == "PLAYING":
            frames += 1
            player.update(pygame.key.get_pressed())
            for battery in batteries:
                battery.update(player)
                if touching(player, battery, PLAYER_RADIUS, BATTERY_RADIUS):
                    score += 1
                    player.power = min(MAX_POWER, player.power + BATTERY_POWER)
                    battery.respawn(player)
            for hunter in hunters:
                hunter.update(player)
                # Cooldown stops one touch from draining power every frame
                if touching(player, hunter, PLAYER_RADIUS, HUNTER_RADIUS) and not player.hit_cooldown:
                    player.take_hit(hunter)
                    hunter.hit_player()
            if score >= WIN_SCORE:
                state = "WON"
            elif player.power <= 0:
                state = "LOST"

        screen.fill(BG)
        cone_layer.fill((0, 0, 0, 0))
        for hunter in hunters:
            hunter.draw_cone(cone_layer)
        screen.blit(cone_layer, (0, 0))
        pygame.draw.circle(screen, (40, 70, 90), player.position, MAGNET_RANGE, 1)  # magnet range
        for battery in batteries:
            battery.draw(screen, player)
        for hunter in hunters:
            hunter.draw(screen, small_font)
        player.draw(screen)
        draw_hud(screen, font, player, score)

        seconds = frames // FPS
        if state == "START":
            draw_menu(screen, big_font, font, "DRONE HUNTER", PLAYER_COLOR, START_LINES)
        elif state == "WON":
            draw_menu(screen, big_font, font, "FULLY CHARGED!", GREEN,
                      [f"All {WIN_SCORE} batteries in {seconds} seconds.", "", f"R: play again{QUIT_HINT}"])
        elif state == "LOST":
            draw_menu(screen, big_font, font, "OUT OF POWER", RED,
                      [f"Batteries: {score}/{WIN_SCORE}   Time survived: {seconds}s", "",
                       f"R: try again{QUIT_HINT}"])
        pygame.display.flip()
        # Hands control back to the browser each frame (required by pygbag;
        # on the desktop it does nothing noticeable)
        await asyncio.sleep(0)


asyncio.run(main())
